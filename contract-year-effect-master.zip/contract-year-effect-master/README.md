# contract-year-effect
Contract Year Effect in the NBA

We investigate whether the contract year effect is significant in the NBA based on 2014-8 NBA data.
We use OLS fixed effects and double LASSO as our econometric methods.

You can find the raw data and the code (R) for replication purposes.
